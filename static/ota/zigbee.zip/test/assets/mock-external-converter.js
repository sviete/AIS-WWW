const mockDevice = {
    mock: true,
    zigbeeModel: ['external_converter_device'],
    vendor: 'external',
    model: ['external_converter_device'],
    definition: {
        foo: 'bar'
    }
};

module.exports = mockDevice;