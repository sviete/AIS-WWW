const mockDevices = [{
    mock: 1
}, {
    mock: 2
}];

module.exports = mockDevices;