"""Permission constants."""
CAT_ENTITIES = 'entities'
SUBCAT_ALL = 'all'

POLICY_READ = 'read'
POLICY_CONTROL = 'control'
POLICY_EDIT = 'edit'
