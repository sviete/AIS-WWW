declare module 'zigbee2mqtt-frontend' {
    export function getPath(): string;
}
